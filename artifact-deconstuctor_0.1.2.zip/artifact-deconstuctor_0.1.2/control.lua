require "config"

local artifact_polling_delay = math.max(artifact_polling_delay_secs,1)*60

local function find_all_entities(args)
	for _, allPlayers in pairs( game.players ) do
		args.area = {{game.players[allPlayers.index].position.x-search_radius, game.players[allPlayers.index].position.y-search_radius}, {game.players[allPlayers.index].position.x+search_radius, game.players[allPlayers.index].position.y+search_radius}}
		for _, ent in pairs(game.surfaces[1].find_entities_filtered(args)) do
			if game.players[allPlayers.index] and ent.stack.name == "alien-artifact" and not ent.to_be_deconstructed(game.players[allPlayers.index].force) then
				ent.order_deconstruction(game.players[allPlayers.index].force)
			end
		end
	end
	return
end

local function onTick(event)
  if event.tick%artifact_polling_delay == 0 then
	-- debug("Find Artifact")
	find_all_entities({name="item-on-ground"})
  end
end

script.on_event(defines.events.on_tick, onTick)
