# factorio-mod-artifact-deconstructor
A mod for the game Factorio, causing alien artifacts to be deconstructed to be picked up by construction bots.
