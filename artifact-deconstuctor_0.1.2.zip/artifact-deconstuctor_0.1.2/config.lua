-- seconds between artifact checks
artifact_polling_delay_secs = 5

-- square radius searched around players (larger = more area = more lag)
search_radius = 100