data:extend(
{
  {
    type = "item",
    name = "specialized-refinery",
    icon = SR_G_ENTITY_ICON,
    flags = {"goes-to-quickbar"},
    subgroup = "production-machine",
    order = "e[refinery]",
    place_result = "specialized-refinery",
    stack_size = 10
  }
}
)