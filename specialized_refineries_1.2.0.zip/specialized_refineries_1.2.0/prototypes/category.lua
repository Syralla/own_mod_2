data:extend(
{
  {
    type = "recipe-category",
    name = "specialized-oil-processing"
  }
})