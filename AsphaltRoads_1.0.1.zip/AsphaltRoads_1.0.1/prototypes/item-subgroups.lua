data:extend(
{  
    {
        type = "item-subgroup",
        name = "Arci-asphalt",
        group = "logistics",
        order = "i",
    }
})