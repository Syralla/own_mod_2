data:extend(
{
    {
        type = "recipe",
        name = "Arci-asphalt",
        energy_required = 10,
        enabled = false,
        category = "chemistry",
        ingredients =
        {
            {type="fluid", name="crude-oil", amount=3},
            {type="fluid", name="heavy-oil", amount=3},
            {type="item", name="stone-brick", amount=4}
        },
        result= "Arci-asphalt",
        result_count = 10
    },
    {
    	type = "recipe",
        name = "Arci-asphalt-hazard-white",
        energy_required = 0.25,
        enabled = false,
        category = "crafting",
        ingredients =
        {
            {"Arci-asphalt", 10}
        },
        result= "Arci-asphalt-hazard-white",
        result_count = 10
    },
    {
    	type = "recipe",
        name = "Arci-asphalt-hazard-yellow",
        energy_required = 0.25,
        enabled = false,
        category = "crafting",
        ingredients =
        {
            {"Arci-asphalt", 10}
        },
        result= "Arci-asphalt-hazard-yellow",
        result_count = 10
    },
    {
    	type = "recipe",
        name = "Arci-asphalt-hazard-red",
        energy_required = 0.25,
        enabled = false,
        category = "crafting",
        ingredients =
        {
            {"Arci-asphalt", 10}
        },
        result= "Arci-asphalt-hazard-red",
        result_count = 10
    },
    {
    	type = "recipe",
        name = "Arci-asphalt-hazard-blue",
        energy_required = 0.25,
        enabled = false,
        category = "crafting",
        ingredients =
        {
            {"Arci-asphalt", 10}
        },
        result= "Arci-asphalt-hazard-blue",
        result_count = 10
    },
    {
    	type = "recipe",
        name = "Arci-asphalt-marking-white-straight",
        energy_required = 0.25,
        enabled = false,
        category = "crafting",
        ingredients =
        {
            {"Arci-asphalt", 10}
        },
        result= "Arci-asphalt-marking-white-straight",
        result_count = 10
    },
    {
    	type = "recipe",
        name = "Arci-asphalt-marking-white-diagonal",
        energy_required = 0.25,
        enabled = false,
        category = "crafting",
        ingredients =
        {
            {"Arci-asphalt", 10}
        },
        result= "Arci-asphalt-marking-white-diagonal",
        result_count = 10
    },
    {
    	type = "recipe",
        name = "Arci-asphalt-marking-yellow-straight",
        energy_required = 0.25,
        enabled = false,
        category = "crafting",
        ingredients =
        {
            {"Arci-asphalt", 10}
        },
        result= "Arci-asphalt-marking-yellow-straight",
        result_count = 10
    },
    {
    	type = "recipe",
        name = "Arci-asphalt-marking-yellow-diagonal",
        energy_required = 0.25,
        enabled = false,
        category = "crafting",
        ingredients =
        {
            {"Arci-asphalt", 10}
        },
        result= "Arci-asphalt-marking-yellow-diagonal",
        result_count = 10
    },    
    {
    	type = "recipe",
        name = "Arci-asphalt-zebra-crossing",
        energy_required = 0.25,
        enabled = false,
        category = "crafting",
        ingredients =
        {
            {"Arci-asphalt", 10}
        },
        result= "Arci-asphalt-zebra-crossing",
        result_count = 10
    },    
})

  