local asphalt_vehicle_speed_modifier = 0.5 -- concrete: 0.8 
local asphalt_color = {r=54, g=48, b=44}
local asphalt_color_marking_white = {r=60, g=60, b=60}
local asphalt_color_marking_yellow = {r=60, g=60, b=40}
local asphalt_color_marking_blue = {r=40, g=40, b=49}
local asphalt_color_marking_red = {r=49, g=40, b=40}

data:extend(
{
    -- asphalt tile --------------------------------------------------------------------
    {
    
        type = "tile",
        name = "Arci-asphalt",
        needs_correction = false,
        minable = {hardness = 0.2, mining_time = 0.5, result = "Arci-asphalt"},
        mined_sound = { filename = "__base__/sound/deconstruct-bricks.ogg" },
        collision_mask = {"ground-tile"},
        walking_speed_modifier = 1.3,
        layer = 62,
        decorative_removal_probability = 0.97,
        variants =
        {
            main =
            {
                {
                    picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt.png",
                    count = 16,
                    size = 1
                },
                {
                    picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt2.png",
                    count = 4,
                    size = 2,
                    probability = 0.3,
                },
                {
                    picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt4.png",
                    count = 4,
                    size = 4,
                    probability = 0.8,
                },
            },
            inner_corner =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-inner-corner.png",
                count = 8
            },
            outer_corner =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-outer-corner.png",
                count = 8
            },
            side =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-side.png",
                count = 8
            },
            u_transition =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-u.png",
                count = 8
            },
                o_transition =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-o.png",
                count = 1
            }
        },
        walking_sound =
        {
            {
                filename = "__base__/sound/walking/concrete-01.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-02.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-03.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-04.ogg",
                volume = 1.2
            }
        },
        map_color = asphalt_color,
        ageing=0,
        vehicle_friction_modifier = asphalt_vehicle_speed_modifier 
    },
    -- asphalt zebra crossing tiles ----------------------------------------------------
    {
        type = "tile",
        name = "Arci-asphalt-zebra-crossing-horizontal",
        next_direction = "Arci-asphalt-zebra-crossing-vertical",
        needs_correction = false,
        minable = {hardness = 0.2, mining_time = 0.5, result = "Arci-asphalt"},
        mined_sound = { filename = "__base__/sound/deconstruct-bricks.ogg" },
        collision_mask = {"ground-tile"},
        walking_speed_modifier = 1.3,
        layer = 62,
        decorative_removal_probability = 0.97,
        variants =
        {
            main =
            {
                {
                    picture = "__AsphaltRoads__/graphics/terrain/asphalt-zebra-crossing-horizontal/azch1.png",
                    count = 16,
                    size = 1
                },
                {
                    picture = "__AsphaltRoads__/graphics/terrain/asphalt-zebra-crossing-horizontal/azch2.png",
                    count = 4,
                    size = 2,
                    probability = 0.3,
                },
                {
                    picture = "__AsphaltRoads__/graphics/terrain/asphalt-zebra-crossing-horizontal/azch4.png",
                    count = 4,
                    size = 4,
                    probability = 0.8,
                },
            },
            inner_corner =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-inner-corner.png",
                count = 8
            },
            outer_corner =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-outer-corner.png",
                count = 8
            },
            side =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-side.png",
                count = 8
            },
            u_transition =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-u.png",
                count = 8
            },
                o_transition =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-o.png",
                count = 1
            }
        },
        walking_sound =
        {
            {
                filename = "__base__/sound/walking/concrete-01.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-02.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-03.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-04.ogg",
                volume = 1.2
            }
        },
        map_color = asphalt_color_marking_white,
        ageing=0,
        vehicle_friction_modifier = asphalt_vehicle_speed_modifier
    },
    {
        type = "tile",
        name = "Arci-asphalt-zebra-crossing-vertical",
        next_direction = "Arci-asphalt-zebra-crossing-horizontal",
        needs_correction = false,
        minable = {hardness = 0.2, mining_time = 0.5, result = "Arci-asphalt"},
        mined_sound = { filename = "__base__/sound/deconstruct-bricks.ogg" },
        collision_mask = {"ground-tile"},
        walking_speed_modifier = 1.3,
        layer = 62,
        decorative_removal_probability = 0.97,
        variants =
        {
            main =
            {
                {
                    picture = "__AsphaltRoads__/graphics/terrain/asphalt-zebra-crossing-vertical/azcv1.png",
                    count = 16,
                    size = 1
                },
                {
                    picture = "__AsphaltRoads__/graphics/terrain/asphalt-zebra-crossing-vertical/azcv2.png",
                    count = 4,
                    size = 2,
                    probability = 0.3,
                },
                {
                    picture = "__AsphaltRoads__/graphics/terrain/asphalt-zebra-crossing-vertical/azcv4.png",
                    count = 4,
                    size = 4,
                    probability = 0.8,
                },
            },
            inner_corner =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-inner-corner.png",
                count = 8
            },
            outer_corner =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-outer-corner.png",
                count = 8
            },
            side =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-side.png",
                count = 8
            },
            u_transition =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-u.png",
                count = 8
            },
                o_transition =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-o.png",
                count = 1
            }
        },
        walking_sound =
        {
            {
                filename = "__base__/sound/walking/concrete-01.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-02.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-03.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-04.ogg",
                volume = 1.2
            }
        },
        map_color = asphalt_color_marking_white,
        ageing=0,
        vehicle_friction_modifier = asphalt_vehicle_speed_modifier
    },
  
    -- hazard marking tiles ------------------------------------------------------------
    {
        type = "tile",
        name = "Arci-asphalt-hazard-white-left",
        next_direction = "Arci-asphalt-hazard-white-right",
        needs_correction = false,
        minable = {hardness = 0.2, mining_time = 0.5, result = "Arci-asphalt"},
        mined_sound = { filename = "__base__/sound/deconstruct-bricks.ogg" },
        collision_mask = {"ground-tile"},
        walking_speed_modifier = 1.3,
        layer = 62,
        decorative_removal_probability = 0.97,
        variants =
        {
            main =
            {
                {
                    picture = "__AsphaltRoads__/graphics/terrain/asphalt-hazard-white-left/ahwl1.png",
                    count = 16,
                    size = 1
                },
                {
                    picture = "__AsphaltRoads__/graphics/terrain/asphalt-hazard-white-left/ahwl2.png",
                    count = 4,
                    size = 2,
                    probability = 0.3,
                },
                {
                    picture = "__AsphaltRoads__/graphics/terrain/asphalt-hazard-white-left/ahwl4.png",
                    count = 4,
                    size = 4,
                    probability = 0.8,
                },
            },
            inner_corner =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-inner-corner.png",
                count = 8
            },
            outer_corner =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-outer-corner.png",
                count = 8
            },
            side =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-side.png",
                count = 8
            },
            u_transition =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-u.png",
                count = 8
            },
                o_transition =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-o.png",
                count = 1
            }
        },
        walking_sound =
        {
            {
                filename = "__base__/sound/walking/concrete-01.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-02.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-03.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-04.ogg",
                volume = 1.2
            }
        },
        map_color = asphalt_color_marking_white,
        ageing=0,
        vehicle_friction_modifier = asphalt_vehicle_speed_modifier
    },
    {
        type = "tile",
        name = "Arci-asphalt-hazard-white-right",
        next_direction = "Arci-asphalt-hazard-white-left",
        needs_correction = false,
        minable = {hardness = 0.2, mining_time = 0.5, result = "Arci-asphalt"},
        mined_sound = { filename = "__base__/sound/deconstruct-bricks.ogg" },
        collision_mask = {"ground-tile"},
        walking_speed_modifier = 1.3,
        layer = 62,
        decorative_removal_probability = 0.97,
        variants =
        {
            main =
            {
                {
                    picture = "__AsphaltRoads__/graphics/terrain/asphalt-hazard-white-right/ahwr1.png",
                    count = 16,
                    size = 1
                },
                {
                    picture = "__AsphaltRoads__/graphics/terrain/asphalt-hazard-white-right/ahwr2.png",
                    count = 4,
                    size = 2,
                    probability = 0.3,
                },
                {
                    picture = "__AsphaltRoads__/graphics/terrain/asphalt-hazard-white-right/ahwr4.png",
                    count = 4,
                    size = 4,
                    probability = 0.8,
                },
            },
            inner_corner =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-inner-corner.png",
                count = 8
            },
            outer_corner =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-outer-corner.png",
                count = 8
            },
            side =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-side.png",
                count = 8
            },
            u_transition =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-u.png",
                count = 8
            },
                o_transition =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-o.png",
                count = 1
            }
        },
        walking_sound =
        {
            {
                filename = "__base__/sound/walking/concrete-01.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-02.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-03.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-04.ogg",
                volume = 1.2
            }
        },
        map_color = asphalt_color_marking_white,
        ageing=0,
        vehicle_friction_modifier = asphalt_vehicle_speed_modifier
    },
    {
        type = "tile",
        name = "Arci-asphalt-hazard-yellow-left",
        next_direction = "Arci-asphalt-hazard-yellow-right",
        needs_correction = false,
        minable = {hardness = 0.2, mining_time = 0.5, result = "Arci-asphalt"},
        mined_sound = { filename = "__base__/sound/deconstruct-bricks.ogg" },
        collision_mask = {"ground-tile"},
        walking_speed_modifier = 1.3,
        layer = 62,
        decorative_removal_probability = 0.97,
        variants =
        {
            main =
            {
                {
                    picture = "__AsphaltRoads__/graphics/terrain/asphalt-hazard-yellow-left/ahyl1.png",
                    count = 16,
                    size = 1
                },
                {
                    picture = "__AsphaltRoads__/graphics/terrain/asphalt-hazard-yellow-left/ahyl2.png",
                    count = 4,
                    size = 2,
                    probability = 0.3,
                },
                {
                    picture = "__AsphaltRoads__/graphics/terrain/asphalt-hazard-yellow-left/ahyl4.png",
                    count = 4,
                    size = 4,
                    probability = 0.8,
                },
            },
            inner_corner =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-inner-corner.png",
                count = 8
            },
            outer_corner =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-outer-corner.png",
                count = 8
            },
            side =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-side.png",
                count = 8
            },
            u_transition =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-u.png",
                count = 8
            },
                o_transition =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-o.png",
                count = 1
            }
        },
        walking_sound =
        {
            {
                filename = "__base__/sound/walking/concrete-01.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-02.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-03.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-04.ogg",
                volume = 1.2
            }
        },
        map_color = asphalt_color_marking_yellow,
        ageing=0,
        vehicle_friction_modifier = asphalt_vehicle_speed_modifier
    },
    {
        type = "tile",
        name = "Arci-asphalt-hazard-yellow-right",
        next_direction = "Arci-asphalt-hazard-yellow-left",
        needs_correction = false,
        minable = {hardness = 0.2, mining_time = 0.5, result = "Arci-asphalt"},
        mined_sound = { filename = "__base__/sound/deconstruct-bricks.ogg" },
        collision_mask = {"ground-tile"},
        walking_speed_modifier = 1.3,
        layer = 62,
        decorative_removal_probability = 0.97,
        variants =
        {
            main =
            {
                {
                    picture = "__AsphaltRoads__/graphics/terrain/asphalt-hazard-yellow-right/ahyr1.png",
                    count = 16,
                    size = 1
                },
                {
                    picture = "__AsphaltRoads__/graphics/terrain/asphalt-hazard-yellow-right/ahyr2.png",
                    count = 4,
                    size = 2,
                    probability = 0.3,
                },
                {
                    picture = "__AsphaltRoads__/graphics/terrain/asphalt-hazard-yellow-right/ahyr4.png",
                    count = 4,
                    size = 4,
                    probability = 0.8,
                },
            },
            inner_corner =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-inner-corner.png",
                count = 8
            },
            outer_corner =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-outer-corner.png",
                count = 8
            },
            side =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-side.png",
                count = 8
            },
            u_transition =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-u.png",
                count = 8
            },
                o_transition =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-o.png",
                count = 1
            }
        },
        walking_sound =
        {
            {
                filename = "__base__/sound/walking/concrete-01.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-02.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-03.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-04.ogg",
                volume = 1.2
            }
        },
        map_color = asphalt_color_marking_yellow,
        ageing=0,
        vehicle_friction_modifier = asphalt_vehicle_speed_modifier
    },
    {
        type = "tile",
        name = "Arci-asphalt-hazard-red-left",
        next_direction = "Arci-asphalt-hazard-red-right",
        needs_correction = false,
        minable = {hardness = 0.2, mining_time = 0.5, result = "Arci-asphalt"},
        mined_sound = { filename = "__base__/sound/deconstruct-bricks.ogg" },
        collision_mask = {"ground-tile"},
        walking_speed_modifier = 1.3,
        layer = 62,
        decorative_removal_probability = 0.97,
        variants =
        {
            main =
            {
                {
                    picture = "__AsphaltRoads__/graphics/terrain/asphalt-hazard-red-left/ahrl1.png",
                    count = 16,
                    size = 1
                },
                {
                    picture = "__AsphaltRoads__/graphics/terrain/asphalt-hazard-red-left/ahrl2.png",
                    count = 4,
                    size = 2,
                    probability = 0.3,
                },
                {
                    picture = "__AsphaltRoads__/graphics/terrain/asphalt-hazard-red-left/ahrl4.png",
                    count = 4,
                    size = 4,
                    probability = 0.8,
                },
            },
            inner_corner =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-inner-corner.png",
                count = 8
            },
            outer_corner =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-outer-corner.png",
                count = 8
            },
            side =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-side.png",
                count = 8
            },
            u_transition =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-u.png",
                count = 8
            },
                o_transition =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-o.png",
                count = 1
            }
        },
        walking_sound =
        {
            {
                filename = "__base__/sound/walking/concrete-01.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-02.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-03.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-04.ogg",
                volume = 1.2
            }
        },
        map_color = asphalt_color_marking_red,
        ageing=0,
        vehicle_friction_modifier = asphalt_vehicle_speed_modifier
    },
    {
        type = "tile",
        name = "Arci-asphalt-hazard-red-right",
        next_direction = "Arci-asphalt-hazard-red-left",
        needs_correction = false,
        minable = {hardness = 0.2, mining_time = 0.5, result = "Arci-asphalt"},
        mined_sound = { filename = "__base__/sound/deconstruct-bricks.ogg" },
        collision_mask = {"ground-tile"},
        walking_speed_modifier = 1.3,
        layer = 62,
        decorative_removal_probability = 0.97,
        variants =
        {
            main =
            {
                {
                    picture = "__AsphaltRoads__/graphics/terrain/asphalt-hazard-red-right/ahrr1.png",
                    count = 16,
                    size = 1
                },
                {
                    picture = "__AsphaltRoads__/graphics/terrain/asphalt-hazard-red-right/ahrr2.png",
                    count = 4,
                    size = 2,
                    probability = 0.3,
                },
                {
                    picture = "__AsphaltRoads__/graphics/terrain/asphalt-hazard-red-right/ahrr4.png",
                    count = 4,
                    size = 4,
                    probability = 0.8,
                },
            },
            inner_corner =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-inner-corner.png",
                count = 8
            },
            outer_corner =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-outer-corner.png",
                count = 8
            },
            side =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-side.png",
                count = 8
            },
            u_transition =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-u.png",
                count = 8
            },
                o_transition =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-o.png",
                count = 1
            }
        },
        walking_sound =
        {
            {
                filename = "__base__/sound/walking/concrete-01.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-02.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-03.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-04.ogg",
                volume = 1.2
            }
        },
        map_color = asphalt_color_marking_red,
        ageing=0,
        vehicle_friction_modifier = asphalt_vehicle_speed_modifier
    },
    {
        type = "tile",
        name = "Arci-asphalt-hazard-blue-left",
        next_direction = "Arci-asphalt-hazard-blue-right",
        needs_correction = false,
        minable = {hardness = 0.2, mining_time = 0.5, result = "Arci-asphalt"},
        mined_sound = { filename = "__base__/sound/deconstruct-bricks.ogg" },
        collision_mask = {"ground-tile"},
        walking_speed_modifier = 1.3,
        layer = 62,
        decorative_removal_probability = 0.97,
        variants =
        {
            main =
            {
                {
                    picture = "__AsphaltRoads__/graphics/terrain/asphalt-hazard-blue-left/ahbl1.png",
                    count = 16,
                    size = 1
                },
                {
                    picture = "__AsphaltRoads__/graphics/terrain/asphalt-hazard-blue-left/ahbl2.png",
                    count = 4,
                    size = 2,
                    probability = 0.3,
                },
                {
                    picture = "__AsphaltRoads__/graphics/terrain/asphalt-hazard-blue-left/ahbl4.png",
                    count = 4,
                    size = 4,
                    probability = 0.8,
                },
            },
            inner_corner =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-inner-corner.png",
                count = 8
            },
            outer_corner =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-outer-corner.png",
                count = 8
            },
            side =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-side.png",
                count = 8
            },
            u_transition =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-u.png",
                count = 8
            },
                o_transition =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-o.png",
                count = 1
            }
        },
        walking_sound =
        {
            {
                filename = "__base__/sound/walking/concrete-01.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-02.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-03.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-04.ogg",
                volume = 1.2
            }
        },
        map_color = asphalt_color_marking_blue,
        ageing=0,
        vehicle_friction_modifier = asphalt_vehicle_speed_modifier
    },
    {
        type = "tile",
        name = "Arci-asphalt-hazard-blue-right",
        next_direction = "Arci-asphalt-hazard-blue-left",
        needs_correction = false,
        minable = {hardness = 0.2, mining_time = 0.5, result = "Arci-asphalt"},
        mined_sound = { filename = "__base__/sound/deconstruct-bricks.ogg" },
        collision_mask = {"ground-tile"},
        walking_speed_modifier = 1.3,
        layer = 62,
        decorative_removal_probability = 0.97,
        variants =
        {
            main =
            {
                {
                    picture = "__AsphaltRoads__/graphics/terrain/asphalt-hazard-blue-right/ahbr1.png",
                    count = 16,
                    size = 1
                },
                {
                    picture = "__AsphaltRoads__/graphics/terrain/asphalt-hazard-blue-right/ahbr2.png",
                    count = 4,
                    size = 2,
                    probability = 0.3,
                },
                {
                    picture = "__AsphaltRoads__/graphics/terrain/asphalt-hazard-blue-right/ahbr4.png",
                    count = 4,
                    size = 4,
                    probability = 0.8,
                },
            },
            inner_corner =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-inner-corner.png",
                count = 8
            },
            outer_corner =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-outer-corner.png",
                count = 8
            },
            side =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-side.png",
                count = 8
            },
            u_transition =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-u.png",
                count = 8
            },
                o_transition =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-o.png",
                count = 1
            }
        },
        walking_sound =
        {
            {
                filename = "__base__/sound/walking/concrete-01.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-02.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-03.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-04.ogg",
                volume = 1.2
            }
        },
        map_color = asphalt_color_marking_blue,
        ageing=0,
        vehicle_friction_modifier = asphalt_vehicle_speed_modifier
    },
    -- lane marking tiles --------------------------------------------------------------
    {
        type = "tile",
        name = "Arci-asphalt-marking-white-ns",
        next_direction = "Arci-asphalt-marking-white-we",
        needs_correction = false,
        minable = {hardness = 0.2, mining_time = 0.5, result = "Arci-asphalt"},
        mined_sound = { filename = "__base__/sound/deconstruct-bricks.ogg" },
        collision_mask = {"ground-tile"},
        walking_speed_modifier = 1.3,
        layer = 62,
        decorative_removal_probability = 0.97,
        variants =
        {
            main =
            {
                {
                    picture = "__AsphaltRoads__/graphics/terrain/marking-white-ns/amw-ns.png",
                    count = 16,
                    size = 1
                }
            },
            inner_corner =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-inner-corner.png",
                count = 8
            },
            outer_corner =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-outer-corner.png",
                count = 8
            },
            side =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-side.png",
                count = 8
            },
            u_transition =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-u.png",
                count = 8
            },
                o_transition =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-o.png",
                count = 1
            }
        },
        walking_sound =
        {
            {
                filename = "__base__/sound/walking/concrete-01.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-02.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-03.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-04.ogg",
                volume = 1.2
            }
        },
        map_color = asphalt_color_marking_white,
        ageing=0,
        vehicle_friction_modifier = asphalt_vehicle_speed_modifier
    },
    {
        type = "tile",
        name = "Arci-asphalt-marking-white-swne",
        next_direction = "Arci-asphalt-marking-white-nwse",
        needs_correction = false,
        minable = {hardness = 0.2, mining_time = 0.5, result = "Arci-asphalt"},
        mined_sound = { filename = "__base__/sound/deconstruct-bricks.ogg" },
        collision_mask = {"ground-tile"},
        walking_speed_modifier = 1.3,
        layer = 63,
        decorative_removal_probability = 0.97,
        variants =
        {
            main =
            {
                {
                    picture = "__AsphaltRoads__/graphics/terrain/marking-white-swne/amw-swne.png",
                    count = 16,
                    size = 1
                }
            },
            inner_corner =
            {
                picture = "__AsphaltRoads__/graphics/terrain/marking-white-swne/amw-swne-inner-corner.png",
                count = 8
            },
            outer_corner =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-outer-corner.png",
                count = 8
            },
            side =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-side.png",
                count = 8
            },
            u_transition =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-u.png",
                count = 8
            },
                o_transition =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-o.png",
                count = 1
            }
        },
        walking_sound =
        {
            {
                filename = "__base__/sound/walking/concrete-01.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-02.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-03.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-04.ogg",
                volume = 1.2
            }
        },
        map_color = asphalt_color_marking_white,
        ageing=0,
        vehicle_friction_modifier = asphalt_vehicle_speed_modifier
    },
    {
        type = "tile",
        name = "Arci-asphalt-marking-white-we",
        next_direction = "Arci-asphalt-marking-white-ns",
        needs_correction = false,
        minable = {hardness = 0.2, mining_time = 0.5, result = "Arci-asphalt"},
        mined_sound = { filename = "__base__/sound/deconstruct-bricks.ogg" },
        collision_mask = {"ground-tile"},
        walking_speed_modifier = 1.3,
        layer = 62,
        decorative_removal_probability = 0.97,
        variants =
        {
            main =
            {
                {
                    picture = "__AsphaltRoads__/graphics/terrain/marking-white-we/amw-we.png",
                    count = 16,
                    size = 1
                }
            },
            inner_corner =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-inner-corner.png",
                count = 8
            },
            outer_corner =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-outer-corner.png",
                count = 8
            },
            side =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-side.png",
                count = 8
            },
            u_transition =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-u.png",
                count = 8
            },
                o_transition =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-o.png",
                count = 1
            }
        },
        walking_sound =
        {
            {
                filename = "__base__/sound/walking/concrete-01.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-02.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-03.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-04.ogg",
                volume = 1.2
            }
        },
        map_color = asphalt_color_marking_white,
        ageing=0,
        vehicle_friction_modifier = asphalt_vehicle_speed_modifier
    },    
    {
    
        type = "tile",
        name = "Arci-asphalt-marking-white-nwse",
        next_direction = "Arci-asphalt-marking-white-swne",
        needs_correction = false,
        minable = {hardness = 0.2, mining_time = 0.5, result = "Arci-asphalt"},
        mined_sound = { filename = "__base__/sound/deconstruct-bricks.ogg" },
        collision_mask = {"ground-tile"},
        walking_speed_modifier = 1.3,
        layer = 63,
        decorative_removal_probability = 0.97,
        variants =
        {
            main =
            {
                {
                    picture = "__AsphaltRoads__/graphics/terrain/marking-white-nwse/amw-nwse.png",
                    count = 16,
                    size = 1
                }
            },
            inner_corner =
            {
                picture = "__AsphaltRoads__/graphics/terrain/marking-white-nwse/amw-nwse-inner-corner.png",
                count = 8
            },
            outer_corner =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-outer-corner.png",
                count = 8
            },
            side =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-side.png",
                count = 8
            },
            u_transition =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-u.png",
                count = 8
            },
                o_transition =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-o.png",
                count = 1
            }
        },
        walking_sound =
        {
            {
                filename = "__base__/sound/walking/concrete-01.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-02.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-03.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-04.ogg",
                volume = 1.2
            }
        },
        map_color = asphalt_color_marking_white,
        ageing=0,
        vehicle_friction_modifier = asphalt_vehicle_speed_modifier
    },    
    {
        type = "tile",
        name = "Arci-asphalt-marking-yellow-ns",
        next_direction = "Arci-asphalt-marking-yellow-we",
        needs_correction = false,
        minable = {hardness = 0.2, mining_time = 0.5, result = "Arci-asphalt"},
        mined_sound = { filename = "__base__/sound/deconstruct-bricks.ogg" },
        collision_mask = {"ground-tile"},
        walking_speed_modifier = 1.3,
        layer = 62,
        decorative_removal_probability = 0.97,
        variants =
        {
            main =
            {
                {
                    picture = "__AsphaltRoads__/graphics/terrain/marking-yellow-ns/amy-ns.png",
                    count = 16,
                    size = 1
                }
            },
            inner_corner =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-inner-corner.png",
                count = 8
            },
            outer_corner =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-outer-corner.png",
                count = 8
            },
            side =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-side.png",
                count = 8
            },
            u_transition =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-u.png",
                count = 8
            },
                o_transition =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-o.png",
                count = 1
            }
        },
        walking_sound =
        {
            {
                filename = "__base__/sound/walking/concrete-01.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-02.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-03.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-04.ogg",
                volume = 1.2
            }
        },
        map_color = asphalt_color_marking_yellow,
        ageing=0,
        vehicle_friction_modifier = asphalt_vehicle_speed_modifier
    },
    {
        type = "tile",
        name = "Arci-asphalt-marking-yellow-swne",
        next_direction = "Arci-asphalt-marking-yellow-nwse",
        needs_correction = false,
        minable = {hardness = 0.2, mining_time = 0.5, result = "Arci-asphalt"},
        mined_sound = { filename = "__base__/sound/deconstruct-bricks.ogg" },
        collision_mask = {"ground-tile"},
        walking_speed_modifier = 1.3,
        layer = 63,
        decorative_removal_probability = 0.97,
        variants =
        {
            main =
            {
                {
                    picture = "__AsphaltRoads__/graphics/terrain/marking-yellow-swne/amy-swne.png",
                    count = 16,
                    size = 1
                }
            },
            inner_corner =
            {
                picture = "__AsphaltRoads__/graphics/terrain/marking-yellow-swne/amy-swne-inner-corner.png",
                count = 8
            },
            outer_corner =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-outer-corner.png",
                count = 8
            },
            side =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-side.png",
                count = 8
            },
            u_transition =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-u.png",
                count = 8
            },
                o_transition =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-o.png",
                count = 1
            }
        },
        walking_sound =
        {
            {
                filename = "__base__/sound/walking/concrete-01.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-02.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-03.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-04.ogg",
                volume = 1.2
            }
        },
        map_color = asphalt_color_marking_yellow,
        ageing=0,
        vehicle_friction_modifier = asphalt_vehicle_speed_modifier
    },
    {
        type = "tile",
        name = "Arci-asphalt-marking-yellow-we",
        next_direction = "Arci-asphalt-marking-yellow-ns",
        needs_correction = false,
        minable = {hardness = 0.2, mining_time = 0.5, result = "Arci-asphalt"},
        mined_sound = { filename = "__base__/sound/deconstruct-bricks.ogg" },
        collision_mask = {"ground-tile"},
        walking_speed_modifier = 1.3,
        layer = 62,
        decorative_removal_probability = 0.97,
        variants =
        {
            main =
            {
                {
                    picture = "__AsphaltRoads__/graphics/terrain/marking-yellow-we/amy-we.png",
                    count = 16,
                    size = 1
                }
            },
            inner_corner =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-inner-corner.png",
                count = 8
            },
            outer_corner =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-outer-corner.png",
                count = 8
            },
            side =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-side.png",
                count = 8
            },
            u_transition =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-u.png",
                count = 8
            },
                o_transition =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-o.png",
                count = 1
            }
        },
        walking_sound =
        {
            {
                filename = "__base__/sound/walking/concrete-01.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-02.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-03.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-04.ogg",
                volume = 1.2
            }
        },
        map_color = asphalt_color_marking_yellow,
        ageing=0,
        vehicle_friction_modifier = asphalt_vehicle_speed_modifier
    },    
    {
        type = "tile",
        name = "Arci-asphalt-marking-yellow-nwse",
        next_direction = "Arci-asphalt-marking-yellow-swne",
        needs_correction = false,
        minable = {hardness = 0.2, mining_time = 0.5, result = "Arci-asphalt"},
        mined_sound = { filename = "__base__/sound/deconstruct-bricks.ogg" },
        collision_mask = {"ground-tile"},
        walking_speed_modifier = 1.3,
        layer = 63,
        decorative_removal_probability = 0.97,
        variants =
        {
            main =
            {
                {
                    picture = "__AsphaltRoads__/graphics/terrain/marking-yellow-nwse/amy-nwse.png",
                    count = 16,
                    size = 1
                }
            },
            inner_corner =
            {
                picture = "__AsphaltRoads__/graphics/terrain/marking-yellow-nwse/amy-nwse-inner-corner.png",
                count = 8
            },
            outer_corner =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-outer-corner.png",
                count = 8
            },
            side =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-side.png",
                count = 8
            },
            u_transition =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-u.png",
                count = 8
            },
                o_transition =
            {
                picture = "__AsphaltRoads__/graphics/terrain/asphalt/asphalt-o.png",
                count = 1
            }
        },
        walking_sound =
        {
            {
                filename = "__base__/sound/walking/concrete-01.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-02.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-03.ogg",
                volume = 1.2
            },
            {
                filename = "__base__/sound/walking/concrete-04.ogg",
                volume = 1.2
            }
        },
        map_color = asphalt_color_marking_yellow,
        ageing=0,
        vehicle_friction_modifier = asphalt_vehicle_speed_modifier
    }    

})