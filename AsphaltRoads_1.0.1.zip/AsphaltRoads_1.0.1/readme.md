# Asphalt Roads 1.0.1
---
## Introduction

*Useful for rapid individual transit, pretty roads for city blocks within your base and of course: racing tracks*


**Asphalt Roads**

"Asphalt Roads" adds a new tile set with a smooth, black road surface to your games, including tiles for hazard marking and lane marking. Enjoy the reduced vehicle friction modifier and accelerate up to 150 km/h with your car. 

- Mark separate lanes on your roads
- Mark hazard areas near railway crossings or gates
- Set up pedestrian crossings with the zebra crossing tile

## Details

### Items


![Imgur](http://i.imgur.com/50QaoKq.png)

1. **Asphalt** is the base tile. 

2. **Asphalt with lane marking** consists of four separate items for white and yellow lane marking in 45, 90, 135 and 180 degree angles. To allow compability with blueprint rotation diagonal and straight tiles are separated.

3. **Asphalt with zebra crossing marking** are two tiles intended for the use as pedestrian crossings

4. **Asphalt with hazard marking** are four separate items for white, yellow, red and blue hazard marking. 



### Technology
Basic technology is called **Asphalt** and needs concrete as a prerequisite.

### Effects on gameplay

This mod is mostly non-game-changing, apart from the reduced vehicle friction of asphalt. But this is compensated by the significant amount of crude and heavy oil needed for the production of asphalt.

### Current language support

- EN (English)
- DE (German)

If you like this mod and you've created a translation of your own, please do not hesitate to send me this, so that it can be made accessible to all in the next version. Thanks in advance!

---

### Changelog
 
1.0.1 (2016-12-31)

- minor bugfix: added unique localised string identifiers to avoid problems with other mods
- balancing: reduced amount of bricks needed for asphalt by 20%
- improved map colours
- added correct picture for tile overview


 1.0.0 (2016-12-23) 	

- initial release 


