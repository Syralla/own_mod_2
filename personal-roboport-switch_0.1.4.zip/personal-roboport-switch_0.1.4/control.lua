require("src.main")
require("remote")

local function on_init()
  -- Keeps track whether a unit has its roboports currently disabled
  -- [unit-number] = boolean
  global.is_deactivated = { }
  -- List of stationary base networks where personal roboports are deactivated for each unit
  -- [unit-number] = array of LuaLogisticNetwork
  global.deactivated_base_networks = { }
  -- List of entity-projected networks where personal roboports are deactivated for each unit.
  -- We need this as separate informtation because mobile networks can change their identity when they are deactivated by this mod.
  -- [unit-number] = array of LuaEntity
  global.deactivated_entity_networks = { }
  -- List of player-projected networks where personal roboports are deactivated for each unit.
  -- We need this as separate informtation because mobile networks can change their identity when they are deactivated by this mod.
  -- [unit-number] = array of player-index
  global.deactivated_player_networks = { }
  -- Dictionary mapping a player's index to the roboport equipment they are currently carrying
  -- [player-index] = array of LuaEquipment
  global.unit_roboports = { }
  -- The tick a unit is checked for being in a network
  -- [unit-number] = tick
  global.unit_ticks = { }
  
  -- Map unit numbers to entities
  -- [unit-number] = entity
  global.entities = { }
  -- Map unit numbers to equipment grids for a uniform treatment of players and vehicles (player entities don't have .grid properties).
  -- [unit-number] = LuaEquipmentGrid
  global.grids = { }
  -- Keep track of the unit number associated with each player's character so we have access to it even when the player disconnects.
  -- [player-index] = unit-number
  global.player_units = { }
  
  -- Maps the prototype name of an enabled roboport to the disabled counterpart
  -- [name] = name
  global.disabled_roboport_name = { }
  -- Maps the prototype name of a disabled roboport to the enabled counterpart
  -- [name] = name
  global.enabled_roboport_name = { }
  
  find_roboport_counterparts()
end

local function on_load()
end

local function on_configuration_changed(data)
  find_roboport_counterparts()
end

script.on_init(on_init)
script.on_load(on_load)
script.on_configuration_changed(on_configuration_changed)

script.on_event("personal-roboport-switch-toggle-automatic-mode", toggle_automatic_mode)

script.on_event(defines.events.on_built_entity, on_built_entity)
script.on_event(defines.events.on_entity_died, on_entity_died)
script.on_event(defines.events.on_player_armor_inventory_changed, on_player_armor_inventory_changed)
script.on_event(defines.events.on_player_created, on_player_created)
script.on_event(defines.events.on_player_left_game, on_player_left_game)
script.on_event(defines.events.on_player_placed_equipment, on_player_placed_equipment)
script.on_event(defines.events.on_player_removed_equipment, on_player_removed_equipment)
script.on_event(defines.events.on_pre_player_died, on_pre_player_died)
script.on_event(defines.events.on_preplayer_mined_item, on_preplayer_mined_item)
script.on_event(defines.events.on_tick, on_tick)
