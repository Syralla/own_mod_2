events =
{
}

remote.add_interface("personal-roboport-switch", {
})
