data:extend
{
  {
  	type = "custom-input",
  	name = "personal-roboport-switch-toggle-automatic-mode",
  	key_sequence =  "O",
  	consuming = "script-only",
  },
}
