









local activate_personal_roboports
local check_equipment_grid
local check_player_armor
local deactivate_personal_roboports
local delete_unit
local find_all_construction_cells_by_position
local invalidate_player
local is_entity_only_in_deactivated_networks
local make_network_toggle_filter_for_entity
local on_equipment_changed
local process_unit
local start_tracking_unit
local stop_tracking_player
local stop_tracking_unit
local swap_personal_roboports
local toggle_automatic_mode_for_entity
local toggle_automatic_mode_for_entity_and_cell
local validate_entities
local validate_equipment
local validate_networks

local empty_table = { }

local sort = table.sort
local function find(tbl, x)
  for k, v in pairs(tbl) do
    if(v == x) then
      return k
    end
  end
  return nil
end

-- first on_tick data validation
-------------------------------------------------------------------------------

validate_entities = function()
  local grids = global.grids
  for unit, entity in pairs(global.entities) do
    if(not entity.valid) then
      stop_tracking_unit(unit)
    else
      local grid = grids[unit]
      if(not (grid and grid.valid)) then
        stop_tracking_unit(unit)
      end
    end
  end
end

validate_equipment = function()
  local remove = table.remove
  for unit, roboports in pairs(global.unit_roboports) do
    for i = #roboports, 1, -1 do
      if(not roboports[i].valid) then
        remove(roboports, i)
      end
    end
    if(#roboports == 0) then
      stop_tracking_unit(unit)
    end
  end
end

validate_networks = function()
  local remove = table.remove
  for unit, networks in pairs(global.deactivated_base_networks) do
    for i = #networks, 1, -1 do
      if(not networks[i].valid) then
        remove(networks, i)
      end
    end
  end
  for unit, entities in pairs(global.deactivated_entity_networks) do
    for i = #entities, 1, -1 do
      if(not entities[i].valid) then
        remove(entities, i)
      end
    end
  end
end

-- prototype analysis
-------------------------------------------------------------------------------

function find_roboport_counterparts()
  local disabled_roboport_name = { }
  local enabled_roboport_name = { }
  local match = string.match
  local pattern = "^" .. "personal-roboport-switch-disabled-" .. "(.+)"
  
  for name, data in pairs(game.equipment_prototypes) do
    if(data.type == "roboport-equipment") then
      local first, last = string.find(name, "personal-roboport-switch-disabled-", 1, true)
      if(first) then
        local enabled_name = string.sub(name, last + 1)
        
        disabled_roboport_name[enabled_name] = name
        enabled_roboport_name[name] = enabled_name
      end
    end
  end
  global.disabled_roboport_name = disabled_roboport_name
  global.enabled_roboport_name = enabled_roboport_name
end

-- Equipment management
-------------------------------------------------------------------------------

check_equipment_grid = function(entity, grid)
  local roboports = { }
  for _, equipment in pairs(grid.equipment) do
    if(equipment.type == "roboport-equipment") then
      roboports[#roboports + 1] = equipment
    end
  end
  if(#roboports > 0) then
    start_tracking_unit(entity, grid, roboports)
    return
  end
  stop_tracking_unit(entity.unit_number)
end

check_player_armor = function(player_index)
  local player = game.players[player_index]
  if(player.connected) then
    local entity = player.character
    if(entity and entity.valid) then
      local unit = entity.unit_number
      local item = player.get_inventory(defines.inventory.player_armor)[1]
      local grid = item.valid_for_read and item.grid
      if(grid) then
        global.grids[unit] = grid
        global.entities[unit] = entity
        check_equipment_grid(entity, grid)
        return
      else
        global.grids[unit] = nil
        global.entities[unit] = nil
      end
    end
  end
  stop_tracking_player(player_index)
end

swap_personal_roboports = function(grid, roboports, swap)
  for _, roboport in pairs(roboports) do
    local position = roboport.position
    local energy = roboport.energy
    local name = swap[roboport.name]
    if(name) then
      local items = grid.take(roboport)
      local new_roboport = grid.put{name = name, position = position}
      if(new_roboport) then
        new_roboport.energy = energy
      end
      roboports[_] = new_roboport
    end
  end
end

activate_personal_roboports = function(grid, roboports)
  
  swap_personal_roboports(grid, roboports, global.enabled_roboport_name)
end

deactivate_personal_roboports = function(grid, roboports)
  
  swap_personal_roboports(grid, roboports, global.disabled_roboport_name)
end

on_equipment_changed = function(grid, equipment)
  -- eqiupment can be either a LuaEquipment object or the prototype name string
  if(type(equipment) == "table") then
    equipment = equipment.type
  else
    equipment = game.equipment_prototypes[equipment].type
  end
  
  if(equipment == "roboport-equipment") then
    for unit, entity in pairs(global.entities) do
      if(entity.valid) then
        local entity_grid = global.grids[unit]
        if(entity_grid and entity_grid.valid and entity_grid == grid) then
          check_equipment_grid(entity, entity_grid)
          break
        end
      else
        delete_unit(unit)
      end
    end
  end
end

-- Network search
-------------------------------------------------------------------------------

find_all_construction_cells_by_position = function(surface, position, force)
  local cells = { }
  local networks = force.logistic_networks[surface.name]
  for i = 1, #networks do
    local network = networks[i]
    local cell = network.find_cell_closest_to(position)
    if(cell and cell.owner.force == force and cell.is_in_construction_range(position)) then
      cells[#cells + 1] = cell
    end
  end
  return cells
end

is_entity_only_in_deactivated_networks = function(entity)
  local unit = entity.unit_number
  local deactivated_base_networks = global.deactivated_base_networks[unit] or empty_table
  local deactivated_entity_networks = global.deactivated_entity_networks[unit] or empty_table
  local deactivated_player_networks = global.deactivated_player_networks[unit] or empty_table
  local cells = find_all_construction_cells_by_position(entity.surface, entity.position, entity.force)
  local deactivated = #cells
  for i = 1, #cells do
    local cell = cells[i]
    local owner = cell.owner
    if(owner ~= entity) then
      if(owner.type == "player") then
        if(not find(deactivated_player_networks, owner.player.index)) then
          
          return false
        end
      elseif(cell.mobile) then
        if(not find(deactivated_entity_networks, owner)) then
          
          return false
        end
      else
        if(not find(deactivated_base_networks, cell.logistic_network)) then
          
          return false
        end
      end
    else
      deactivated = deactivated - 1
    end
  end
  return deactivated > 0
end

-- Entity management
-------------------------------------------------------------------------------

start_tracking_unit = function(entity, grid, roboports)
  local unit = entity.unit_number
  
  global.unit_roboports[unit] = roboports
  global.grids[unit] = grid
  global.is_deactivated[unit] = nil
  local tick = global.unit_ticks[unit]
  if(not tick) then
    global.unit_ticks[unit] = game.tick + math.random(60)
  end
end

stop_tracking_unit = function(unit)
  
  global.unit_roboports[unit] = nil
  global.unit_ticks[unit] = nil
end

stop_tracking_player = function(player_index)
  
  local unit = global.player_units[player_index]
  if(unit) then
    stop_tracking_unit(unit)
  end
end

invalidate_player = function(player_index)
  stop_tracking_player(player_index)
  local unit = global.player_units[player_index]
  if(unit) then
    global.entities[unit] = nil
    global.grids[unit] = nil
  end
end

delete_unit = function(unit)
  stop_tracking_unit(unit)
  global.entities[unit] = nil
  global.grids[unit] = nil
  global.deactivated_base_networks[unit] = nil
  global.deactivated_entity_networks[unit] = nil
  global.deactivated_player_networks[unit] = nil
end

process_unit = function(unit)
  local entity = global.entities[unit]
  local grid = global.grids[unit]
  if(entity and entity.valid and grid and grid.valid) then
    local is_deactivated = global.is_deactivated[unit] or false
    local should_be_deactivated = is_entity_only_in_deactivated_networks(entity)
    --
    if(is_deactivated ~= should_be_deactivated) then
      if(is_deactivated) then
        activate_personal_roboports(grid, global.unit_roboports[unit])
        global.is_deactivated[unit] = false
      else
        deactivate_personal_roboports(grid, global.unit_roboports[unit])
        global.is_deactivated[unit] = true
      end
    end
    global.unit_ticks[unit] = game.tick + 60
  else
    delete_unit(unit)
  end
end

-- Network assignments
-------------------------------------------------------------------------------

toggle_automatic_mode_for_entity_and_cell = function(entity, cell)
  local owner = cell.owner
  local unit = entity.unit_number
  local deactivated_base_networks = global.deactivated_base_networks[unit] or { }
  
  local function toggle(networks_table, network_id)
    local deactivated_networks = networks_table[unit] or { }
    local i = find(deactivated_networks, network_id)
    if(i) then
      table.remove(deactivated_networks, i)
    else
      deactivated_networks[#deactivated_networks + 1] = network_id
    end
    networks_table[unit] = deactivated_networks
    return i
  end
  
  local function make_message(key, ...)
    if(entity.type == "player") then
      return {"personal-roboport-switch.player-" .. key, ...}
    else
      return {"personal-roboport-switch.entity-" .. key, entity.localised_name, entity.unit_number, ...}
    end
  end

  if(owner.type == "player") then
    if(toggle(global.deactivated_player_networks, owner.player.index)) then
      return make_message("activate-in-player-network", owner.player.name)
    else
      return make_message("deactivate-in-player-network", owner.player.name)
    end
  elseif(cell.mobile) then
    if(toggle(global.deactivated_entity_networks, owner)) then
      return make_message("activate-in-entity-network", owner.localised_name, owner.unit_number)
    else
      return make_message("deactivate-in-entity-network", owner.localised_name, owner.unit_number)
    end
  else
    if(toggle(global.deactivated_base_networks, cell.logistic_network)) then
      return make_message("activate-in-base-network")
    else
      return make_message("deactivate-in-base-network")
    end
  end
end

make_network_toggle_filter_for_entity = function(entity)
  local entity_vehicle = entity.type == "player" and entity.vehicle
  local train = (entity.type == "locomotive" or entity.type == "cargo-wagon") and entity.train
                or (entity_vehicle and (entity_vehicle.type == "locomotive" or entity_vehicle.type == "cargo-wagon") and entity_vehicle.train)
  return function(cell)
    -- Don't count our own projected network, the vehicle we are driving or passengers/carriages of the same train
    if(cell.mobile) then
      local owner = cell.owner
      local owner_vehicle = owner.type == "player" and owner.vehicle or owner
      if(owner_vehicle == entity or owner_vehicle == entity_vehicle) then
        return false
      elseif(train) then
        local owner_train = (owner_vehicle.type == "locomotive" or owner_vehicle.type == "cargo-wagon") and owner_vehicle.train
        return owner_train ~= train
      else
        return owner ~= entity
      end
    else
      return true
    end
  end
end

toggle_automatic_mode_for_entity = function(entity)
  local unit = entity.unit_number
  local cells = find_all_construction_cells_by_position(entity.surface, entity.position, entity.force)
  local is_cell_relevant = make_network_toggle_filter_for_entity(entity)

  for i = 1, #cells do
    if(not is_cell_relevant(cells[i])) then
      cells[i] = nil
    end
  end
  
  local i, cell = next(cells)
  if(not cell) then
    return {"personal-roboport-switch.no-network-found"}
  end
  
  if(next(cells, i)) then
    return {"personal-roboport-switch.multiple-networks-found"}
  end
  
  return toggle_automatic_mode_for_entity_and_cell(entity, cell)
end

-- Keybinds
-------------------------------------------------------------------------------

function toggle_automatic_mode(event)
  local player = game.players[event.player_index]
  if(player.valid and player.connected and player.character) then
    local entity = player.vehicle
    if(not (entity and global.entities[entity.unit_number])) then
      entity = player.character
    end

    local selected = player.selected
    if(selected) then
      if(selected.logistic_cell) then
        player.print(toggle_automatic_mode_for_entity_and_cell(entity, selected.logistic_cell))
      else
        player.print{"personal-roboport-switch.invalid-entity-selected"}
      end
    else
      player.print(toggle_automatic_mode_for_entity(entity))
    end
  end
end

-- Event entry points
-------------------------------------------------------------------------------

function on_built_entity(event)
  local entity = event.created_entity
  local grid = entity.grid
  local unit = entity.unit_number
  if(grid) then
    global.entities[unit] = entity
    global.grids[unit] = grid
    check_equipment_grid(entity, grid)
  end
end

function on_entity_died(event)
  -- players are treated differently so we can re-apply their settings to the new character entity
  local entity = event.entity
  if(entity.type ~= "player") then
    local unit = entity.unit_number
    if(unit) then
      delete_unit(unit)
    end
  end
end

function on_player_armor_inventory_changed(event)
  check_player_armor(event.player_index)
end

function on_player_created(event)
  local player = game.players[event.player_index]
  if(player.connected) then
    local entity = player.character
    if(entity) then
      -- If we already had settings for this player copy them to the new character unit
      local new_unit = entity.unit_number
      local old_unit = global.player_units[event.player_index]
      if(old_unit and new_unit ~= old_unit) then
        global.deactivated_base_networks[new_unit] = global.deactivated_base_networks[old_unit]
        global.deactivated_base_networks[old_unit] = nil
        global.deactivated_entity_networks[new_unit] = global.deactivated_entity_networks[old_unit]
        global.deactivated_entity_networks[old_unit] = nil
        global.deactivated_player_networks[new_unit] = global.deactivated_player_networks[old_unit]
        global.deactivated_player_networks[old_unit] = nil
        stop_tracking(old_unit)
      end
      check_player_armor(event.player_index)
    end
  end
end

function on_player_left_game(event)
  invalidate_player(event.player_index)
end

function on_player_placed_equipment(event)
  on_equipment_changed(event.grid, event.equipment)
end

function on_player_removed_equipment(event)
  on_equipment_changed(event.grid, event.equipment)
end

function on_pre_player_died(event)
  invalidate_player(event.player_index)
end

function on_preplayer_mined_item(event)
  local unit = event.entity.unit_number
  if(unit) then
    delete_unit(unit)
  end
end

function on_tick(event)
  local function real_on_tick(event)
    local game_tick = event.tick
    for unit, tick in pairs(global.unit_ticks) do
      if(game_tick >= tick) then
        process_unit(unit)
      end
    end
  end

  validate_entities()
  validate_equipment()
  validate_networks()
  script.on_event(defines.events.on_tick, real_on_tick)
end

-- Remote interface
-------------------------------------------------------------------------------
