local equipment = { }
for k, v in pairs(data.raw["roboport-equipment"]) do
  local t = table.deepcopy(v)
  -- Keep the same localised name if none is specified
  t.localised_name = t.localised_name or {"equipment-name." .. t.name}
  -- Some mods don't specify take_result making it default to the equipment name.
  -- If we don't set it the game is going to look for an item with the wrong name.
  t.take_result = t.take_result or t.name
  t.name = "personal-roboport-switch-disabled-" .. t.name
  t.construction_radius = 0
  t.robot_limit = 0
  equipment[#equipment + 1] = t
end
data:extend(equipment)
