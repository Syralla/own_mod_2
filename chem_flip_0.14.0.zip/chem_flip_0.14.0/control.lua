


--[[
script.on_event("flip-fluid-inputs", function(event)
  local player = game.players[event.player_index]
  local entity = player.selected
  if entity and entity.type == "assembling-machine" and entity.fluid_boxes and player.can_reach_entity(entity) then
	for i, box in pairs(entity.fluid_boxes) do
		if box.production_type=="input" then
			box.pipe_connections.position[1]=box.pipe_connections.position[1]*-1
		end
	end
  end
end)
]]