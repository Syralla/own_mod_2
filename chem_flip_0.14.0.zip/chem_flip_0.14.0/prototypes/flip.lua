
local function makeflipped(unflippedname, techname)
if data.raw["item"][unflippedname] and data.raw["assembling-machine"][unflippedname] then
--[[
local fluidboxes = data.raw["assembling-machine"][unflippedname].fluid_boxes
local pos = {}
for i, box in pairs(fluidboxes) do
	if (box.production_type=="input") then pos[#pos+1]=box.pipe_connections[1].position end
end
local c=0
for i, box in pairs(fluidboxes) do
	if (box.production_type=="input") then 
		box.pipe_connections[1].position=pos[#pos-c]
		c=c+1
	end
end
]]
local startenabled=true
if data.raw.technology[techname] then startenabled=false end
data:extend({

  {
    type = "assembling-machine",
    name = unflippedname.."-flipped",
    icon = data.raw["assembling-machine"][unflippedname].icon,
    flags = {"placeable-neutral","placeable-player", "player-creation"},
    minable = {hardness = 0.2, mining_time = 0.5, result = unflippedname},
    max_health = data.raw["assembling-machine"][unflippedname].max_health,
    corpse = "big-remnants",
    dying_explosion = "medium-explosion",
    collision_box = {{-1.4, -1.4}, {1.4, 1.4}},
    selection_box = {{-1.5, -1.5}, {1.5, 1.5}},
    module_specification = data.raw["assembling-machine"][unflippedname].module_specification,
	--[[
    {
      module_slots = 2
    },
	]]
    allowed_effects = data.raw["assembling-machine"][unflippedname].allowed_effects,
    animation = data.raw["assembling-machine"][unflippedname].animation,
	--[[
    {
      north =
      {
        filename = "__base__/graphics/entity/chemical-plant/chemical-plant.png",
        width = 156,
        height = 141,
        frame_count = 1,
        shift = {0.5, -0.078125}
      },
      west =
      {
        filename = "__base__/graphics/entity/chemical-plant/chemical-plant.png",
        x = 468,
        width = 156,
        height = 141,
        frame_count = 1,
        shift = {0.5, -0.078125}
      },
      south =
      {
        filename = "__base__/graphics/entity/chemical-plant/chemical-plant.png",
        x = 312,
        width = 156,
        height = 141,
        frame_count = 1,
        shift = {0.5, -0.078125}
      },
      east =
      {
        filename = "__base__/graphics/entity/chemical-plant/chemical-plant.png",
        x = 156,
        width = 156,
        height = 141,
        frame_count = 1,
        shift = {0.5, -0.078125}
      }
    },
	]]
    working_visualisations = data.raw["assembling-machine"][unflippedname].working_visualisations,
	--[[
    {
      {
        north_position = {0.94, -0.73},
        west_position = {0.05, -1.46},
        south_position = {-0.97, -1.47},
        east_position = {-0.3, 0.02},
        animation =
        {
          filename = "__base__/graphics/entity/chemical-plant/boiling-green-patch.png",
          frame_count = 35,
          width = 17,
          height = 12,
          animation_speed = 0.15
        }
      },
      {
        north_position = {1.4, -0.23},
        west_position = {0.05, -0.96},
        south_position = {-1, -1},
        east_position = {-0.3, 0.55},
        north_animation =
        {
          filename = "__base__/graphics/entity/chemical-plant/boiling-window-green-patch.png",
          frame_count = 1,
          width = 21,
          height = 10
        },
        east_animation =
        {
          filename = "__base__/graphics/entity/chemical-plant/boiling-window-green-patch.png",
          x = 21,
          frame_count = 1,
          width = 21,
          height = 10
        },
        south_animation =
        {
          filename = "__base__/graphics/entity/chemical-plant/boiling-window-green-patch.png",
          x = 42,
          frame_count = 1,
          width = 21,
          height = 10
        }
      }
    },
	]]
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    working_sound = data.raw["assembling-machine"][unflippedname].working_sound,
	--[[
    {
      sound =
      {
        {
          filename = "__base__/sound/chemical-plant.ogg",
          volume = 0.8
        }
      },
      idle_sound = { filename = "__base__/sound/idle1.ogg", volume = 0.6 },
      apparent_volume = 1.5,
    },
	]]
    crafting_speed = data.raw["assembling-machine"][unflippedname].crafting_speed,
    energy_source = data.raw["assembling-machine"][unflippedname].energy_source,
	--[[
    {
      type = "electric",
      usage_priority = "secondary-input",
      emissions = 0.03 / 3.5
    },
	]]
    energy_usage = data.raw["assembling-machine"][unflippedname].energy_usage,
    ingredient_count = data.raw["assembling-machine"][unflippedname].ingredient_count,
    crafting_categories = data.raw["assembling-machine"][unflippedname].crafting_categories,
    fluid_boxes = 
    {
      {
        production_type = "input",
        pipe_covers = pipecoverspictures(),
        base_area = 10,
        base_level = -1,
        pipe_connections = {{ type="input", position = {1, -2} }}
      },
      {
        production_type = "input",
        pipe_covers = pipecoverspictures(),
        base_area = 10,
        base_level = -1,
        pipe_connections = {{ type="input", position = {-1, -2} }}
      },
      {
        production_type = "output",
        pipe_covers = pipecoverspictures(),
        base_level = 1,
        pipe_connections = {{ position = {-1, 2} }}
      },
      {
        production_type = "output",
        pipe_covers = pipecoverspictures(),
        base_level = 1,
        pipe_connections = {{ position = {1, 2} }}
      }
    }
  },
  {
    type = "item",
    name = unflippedname.."-flipped",
    icon = data.raw.item[unflippedname].icon,
    flags = {"goes-to-quickbar"},
    subgroup = data.raw["item"][unflippedname].subgroup,
    order = data.raw["item"][unflippedname].order,
    place_result = unflippedname.."-flipped",
    stack_size = 10
  },
  {
    type = "recipe",
    name = unflippedname.."-flipped",
    energy_required = 0.1,
    enabled = startenabled,
    ingredients =
    {
      {unflippedname, 1}
    },
    result= unflippedname.."-flipped"
  }
})

if data.raw.technology[techname] then
	table.insert(data.raw.technology[techname].effects,{type = "unlock-recipe", recipe = unflippedname.."-flipped"})
end

end
end

local tabletotry={
	{"chemical-plant", "oil-processing"},
	{"chemical-plant-2"},
	{"chemical-plant-3"},
	{"chemical-plant-4"},
	{"electrolyser", "electrolysis-1"},
	{"electrolyser-2"},
	{"electrolyser-3"},
	{"electrolyser-4"}
}

for i, n in pairs(tabletotry) do
	if #n > 1 then
		makeflipped(n[1], n[2])
	else
		makeflipped(n[1], n[1])
	end
end