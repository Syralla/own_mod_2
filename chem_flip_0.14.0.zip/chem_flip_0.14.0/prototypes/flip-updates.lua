local tabletotry={
	"chemical-plant",
	"chemical-plant-2",
	"chemical-plant-3",
	"chemical-plant-4"
}

for i, n in ipairs(tabletotry) do
	local recname = n.."-flipped"
	for j, technology in pairs(data.raw.technology) do
		if data.raw.technology[technology] and data.raw.technology[technology].effects then
			for k, effect in pairs(data.raw.technology[technology].effects) do
			  if effect.type == "unlock-recipe" and effect.recipe == n then
				table.insert(data.raw.technology[technology].effects,{type = "unlock-recipe", recipe = recname}) 
			  end
		    end
		end
	end
end

