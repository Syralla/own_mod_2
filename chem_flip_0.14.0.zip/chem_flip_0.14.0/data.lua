--[[
data:extend({
  {
    type = "custom-input",
    name = "flip-fluid-inputs",
    key_sequence = "SHIFT + R",
    consuming = "script-only"
  }
})
]]
require("prototypes.flip")