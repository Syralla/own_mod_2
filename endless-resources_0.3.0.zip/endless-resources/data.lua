for k, v in pairs(data.raw.resource) do
   data.raw.resource[k].infinite = true
   data.raw.resource[k].minimum  = 175
   data.raw.resource[k].normal   = 350
   
end

