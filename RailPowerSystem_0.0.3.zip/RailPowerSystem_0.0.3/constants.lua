--paths
MODNAME = "__RailPowerSystem__/graphics/"

--train
hybridTrain="hybrid-train"

--rail
railAccu="rail-accu"
powerRail="powered-rail"
railPole="rail-electric-pole"
ghostPole="ghost-electric-pole"
ghostPoleNotSelectable="ghost-electric-pole-not-selectable"
straightRailPower="straight-rail-power"
curvedRailPower="curved-rail-power"