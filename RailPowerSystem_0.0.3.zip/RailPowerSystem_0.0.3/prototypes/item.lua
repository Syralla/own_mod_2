require "constants"

data:extend(
{ 
	{
		type = "rail-planner",
		name = powerRail,
		icon = MODNAME.."items/"..powerRail..".png",
		flags = {"goes-to-quickbar"},
		subgroup = "transport",
		order = "a[train-systems]-b["..powerRail.."]",
		place_result = straightRailPower,
		stack_size = 100,
		straight_rail = straightRailPower,
		curved_rail = curvedRailPower
	},
	{
		type = "item",
		name = ghostPole,
		icon = MODNAME.."items/"..railPole..".png",
		flags = {"hidden"},
		subgroup = "transport",
		order = "zzz",
		place_result = ghostPole,
		stack_size = 0,
	},
	{
		type = "item",
		name = ghostPoleNotSelectable,
		icon = MODNAME.."items/empty.png",
		flags = {"hidden"},
		subgroup = "transport",
		order = "zzz",
		place_result = nil,
		stack_size = 0,
	},
	{
		type = "item",
		name = railAccu,
		icon = MODNAME.."items/"..powerRail..".png",
		flags = {"hidden"},
		subgroup = "transport",
		order = "zzz",
		place_result = railAccu,
		stack_size = 0,
	},
	{
		type = "item",
		name = railPole,
		icon = MODNAME.."items/"..railPole..".png",
		flags = {"goes-to-quickbar"},
		subgroup = "transport",
		order = "a[train-systems]-c["..railPole.."]",
		place_result = railPole,
		stack_size = 50,
	},
	{
		type="item",
		name=hybridTrain,
		icon = MODNAME.."items/"..hybridTrain..".png",
		order = "a[train-systems]-d["..hybridTrain.."]",
		flags = {"goes-to-quickbar"},
		subgroup = "transport",
		place_result = hybridTrain,
		stack_size=5
	},
}) 
