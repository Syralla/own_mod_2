require "constants"

local train_entity = util.table.deepcopy( data.raw["locomotive"]["diesel-locomotive"] )
overwriteContent(train_entity,{
name = hybridTrain,
icon = MODNAME.."items/"..hybridTrain..".png",
minable = { mining_time = 1, result = hybridTrain },
--energy_source = { type = "electric", buffer_capacity = "1200KJ", usage_priority = "secondary-input", input_flow_limit = "600KW", output_flow_limit = "0W" },
color = { r = 100, g = 100, b = 200 },
})



data:extend( { train_entity } )