require "libs.rpsLib"
require "libs.railPowerLib"
require "constants"

local powerrailpicture = function()
  local elems= {{"metals", "metals"}, 
				{"backplates", "backplates"}, 
				{"ties", "ties"}, 
				{"stone_path", "stone-path"}}
  local keys = {{"straight_rail", "horizontal", 64, 64},
                {"straight_rail", "vertical", 64, 64},
                {"straight_rail", "diagonal", 64, 64},
                {"curved_rail", "vertical", 128, 256},
                {"curved_rail" ,"horizontal", 256, 128}}
  local res = {}
  for _ , key in ipairs(keys) do
    part = {}
    dashkey = key[1]:gsub("_", "-")
    for _ , elem in ipairs(elems) do
     part[elem[1] ] = {
       filename = string.format("__RailPowerSystem__/graphics/entity/%s/%s-%s-%s.png", dashkey, dashkey, key[2], elem[2]),
        priority = "extra-high",
        width = key[3],
        height = key[4]
      }
    end
    res[key[1] .. "_" .. key[2] ] = part
  end
  res["rail_endings"] = {
    sheet =
    {
      filename = "__base__/graphics/entity/rail-endings/rail-endings.png",
      priority = "high",
      width = 88,
      height = 82
    }
  }
  return res
end

local railAccuEntity = table.deepcopy(data.raw["electric-energy-interface"]["electric-energy-interface"])
overwriteContent(railAccuEntity, {
	name = railAccu,	
	collision_mask={"not-colliding-with-itself"},
	flags = {"not-on-map","placeable-off-grid"},
	minable = {hardness = 0.2, mining_time = 0.5, result = railAccu},
    collision_box = {{0, 0}, {0, 0}},
    selection_box = {{0, 0}, {0, 0}}, 
	icon = MODNAME.."items/"..powerRail..".png",
	energy_production = "0W",
    energy_usage = "0W",
	energy_source =
    {
      type = "electric",
      buffer_capacity = "11kJ",
      input_flow_limit = "15MJ",
      drain = "0J",
      usage_priority = "primary-input",
	  output_flow_limit = "15MJ",
    },
	picture =
    {
	  filename = "__RailPowerSystem__/graphics/entity/empty-small-electric-pole.png",
      width = 123,
      height = 124,
      direction_count = 4,
      shift = {0, 0},
    },
	vehicle_impact_sound =  nil,
    working_sound =
    {
      sound =
      {
        filename = "__base__/sound/accumulator-working.ogg",
        volume = 0
      },
      idle_sound = {
        filename = "__base__/sound/accumulator-idle.ogg",
        volume = 0
      },
      max_sounds_per_type = 0
    },

})
data:extend({	railAccuEntity })


local railElectricPole = table.deepcopy(data.raw["rail-signal"]["rail-signal"])
overwriteContent(railElectricPole, {
	name = railPole,	
	fast_replaceable_group = nil,
	minable = {mining_time = 0.5, result = railPole},
	selection_box = {{-0.4, -0.4}, {0.4, 0.4}},
    drawing_box = {{-0.5, -2.6}, {0.5, 0.5}},
	animation =
    {
      filename = MODNAME.."entity/"..railPole..".png",
      priority = "high",
      line_length = 1,
      width = 123,
      height = 124,
      frame_count = 1,
	  direction_count = 8,
      shift = {0.7, -1.5},
    },
	
})
data:extend({	railElectricPole })

local ghostElectricPole = table.deepcopy(data.raw["electric-pole"]["small-electric-pole"])
overwriteContent(ghostElectricPole, {
	name = ghostPole,		
	minable = {mining_time = 0.5, result = railPole},
	fast_replaceable_group = nil,
	eflags = {"placeable-neutral", "player-creation", "building-direction-8-way", "filter-directions", "fast-replaceable-no-build-while-moving"},
	supply_area_distance = 1,
	pictures ={
      filename = MODNAME.."entity/"..ghostPole..".png",
	  line_length = 1,
      width = 123,
      height = 124,
      direction_count = 1,
      shift = {0.7, -1.2}
    },
	connection_points =
    {
      {
        shadow =
        {
         copper = {0, -2.75},
          red = {0, -2.63},
          green = {0, -2.63}
        },
        wire =
        {
          copper = {0, -2.7},
          red = {0, -2.625},
          green = {0, -2.625}
        }
      },
    },
	
})	
data:extend({	ghostElectricPole })

local ghostElectricPoleNotSelectable = table.deepcopy(data.raw["electric-pole"][ghostPole])
overwriteContent(ghostElectricPoleNotSelectable, {
	name = ghostPoleNotSelectable,	
	minable=nil,	
	selectable_in_game=false,
	collision_mask={"not-colliding-with-itself"},
	flags = {"not-on-map","placeable-off-grid"},
    drawing_box = {{0, 0}, {0, 0}},
	maximum_wire_distance =3.99, 
	pictures ={
      filename = MODNAME.."entity/empty-small-electric-pole.png",
      line_length = 1,
      width = 123,
      height = 124,
      direction_count = 1,
      shift = {0, 0}
    },	
	connection_points =
    {
      {
        shadow =
        {
          copper = {0, 0},
          red = {0, 0},
          green = {0, 0}
        },
        wire =
        {
          copper = {0, 0},
          red = {0, 0},
          green = {0, 0}
        }
      },
	},
})	
data:extend({	ghostElectricPoleNotSelectable })

local straightRailPowerEntity = table.deepcopy(data.raw["straight-rail"]["straight-rail"])
overwriteContent(straightRailPowerEntity, {
	name = straightRailPower,		
	minable = {mining_time = 0.6, result = powerRail},
	pictures=powerrailpicture()
})	
data:extend({	straightRailPowerEntity })

local curvedRailPowerEntity = table.deepcopy(data.raw["curved-rail"]["curved-rail"])
overwriteContent(curvedRailPowerEntity, {
	name = curvedRailPower,		
	minable = {mining_time = 0.6, result = powerRail, count=4},
	placeable_by = { item=powerRail, count = 4},
	pictures=powerrailpicture()
})	
data:extend({	curvedRailPowerEntity })