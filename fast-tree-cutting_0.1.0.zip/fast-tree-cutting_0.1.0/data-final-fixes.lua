for _, tree in pairs (data.raw.tree) do
	tree.minable.mining_time = 0.1
end