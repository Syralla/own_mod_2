for index, force in pairs(game.forces) do
   local technologies = force.technologies;
   local recipes = force.recipes;

   local add_recipe = function (tech, recipe)
      if technologies[tech].researched then
         recipes[recipe].enabled = true
      end
   end

   add_recipe ("electric-energy-accumulators-1", "solaire-lamp")
end
