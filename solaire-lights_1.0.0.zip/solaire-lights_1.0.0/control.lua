script.on_event (
   {
      defines.events.on_built_entity,
      defines.events.on_robot_built_entity
   },
   function (event)
      local entity = event.created_entity

      if entity.name == "solaire-lamp" then
         local surface = entity.surface
         local pos = entity.position

         local hidden = surface.create_entity{
            name="solaire-power",
            position=pos,
            force=game.forces.neutral
         }
         hidden.destructible = false

         hidden = surface.create_entity{
            name="solaire-storage",
            position=pos,
            force=game.forces.neutral
         }
         hidden.destructible = false

         hidden = surface.create_entity{
            name="solaire-pole",
            position=pos,
            force=game.forces.neutral
         }
         hidden.destructible = false
      end
   end
)


script.on_event (
   {
      defines.events.on_entity_died,
      defines.events.on_preplayer_mined_item,
      defines.events.on_robot_pre_mined
   },
   function (event)
      local entity = event.entity
      if entity.name == "solaire-lamp" then
         local surface = entity.surface
         local pos = entity.position

         local hidden = surface.find_entity ("solaire-power", pos)
         if hidden ~= nil then
            hidden.destroy()
         end

         hidden = surface.find_entity ("solaire-storage", pos)
         if hidden ~= nil then
            hidden.destroy()
         end

         hidden = surface.find_entity ("solaire-pole", pos)
         if hidden ~= nil then
            hidden.destroy()
         end
      end
   end
)
