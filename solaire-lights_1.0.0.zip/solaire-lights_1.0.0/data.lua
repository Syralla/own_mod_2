require "util"

local moddir = "__solaire-lights__"
local icon = moddir.."/graphics/icons/solaire-lamp.png"


local blank = {
   filename = icon,
   priority = "extra-high",
   width = 1,
   height = 1,
   direction_count = 1,
}


-- Use the base lamp entity as the default.
local lamp = util.table.deepcopy (data.raw['lamp']['small-lamp'])
lamp.name = "solaire-lamp"
lamp.icon = icon
lamp.minable.result = "solaire-lamp"
data:extend ({ lamp })


-- Invisible items that allows electricity to flow.
data:extend ({
  {
     type = "solar-panel",
     name = "solaire-power",
     icon = icon,
     flags = {"placeable-off-grid", "not-on-map"},
     max_health = 50,
     corpse = "medium-remnants",
     collision_box = lamp.collision_box,
     energy_source = {
         type = "electric",
         usage_priority = "solar",
     },
     production = "10kW",
     picture = blank,
  },
  {
     type = "accumulator",
     name = "solaire-storage",
     icon = icon,
     flags = {"placeable-off-grid", "not-on-map"},
     max_health = 50,
     corpse = "medium-remnants",
     collision_box = lamp.collision_box,
     energy_source = {
         type = "electric",
         usage_priority = "terciary",
         buffer_capacity = "1MJ",
         input_flow_limit = "50kW",
         output_flow_limit = "50kW",
     },
     picture = blank,
     charge_cooldown = 30,
     discharge_cooldown = 60
  },
  {
     type = "electric-pole",
     name = "solaire-pole",
     icon = icon,
     flags = {"placeable-off-grid", "not-on-map"},
     max_health = 50,
     corpse = "medium-remnants",
     collision_box = lamp.collision_box,
     maximum_wire_distance = 0,
     supply_area_distance = 0.5,
     pictures = blank,
     radius_visualisation_picture = blank,
     connection_points = {
        {
           shadow = {
              copper = {0, 0},
              red = {0, 0},
              green = {0, 0},
           },
           wire = {
              copper = {0, 0},
              red = {0, 0},
              green = {0, 0},
           }
        }
     }
  }
})


-- Items

data:extend({
  {
     type = "item",
     name = "solaire-lamp",
     icon = icon,
     flags = {"goes-to-quickbar"},
     subgroup = "energy",
     order = "c[light]-a[small-lamp]-b[solaire-lamp]",
     place_result = "solaire-lamp",
     stack_size = 50
  },
})


-- Recipes

data:extend({
  {
     type = "recipe",
     name = "solaire-lamp",
     enabled = false,
     ingredients = {
        {"small-lamp", 5},
        {"solar-panel", 1},
        {"accumulator", 1},
     },
     results = {{ name="solaire-lamp", amount=5 }},
  },
})


-- Technology

table.insert(
   data.raw["technology"]["electric-energy-accumulators-1"].effects,
   {
      type="unlock-recipe",
      recipe="solaire-lamp"
   }
)

