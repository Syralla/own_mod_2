# Solaire Lights

*Solaire Lights* mods [Factorio](https://www.factorio.com) providing lamps that are charged by the glorious sun. Useful when attacking enemy bases or establishing outposts, provided the lamps have time to charge. They can also be employed as mini-accumulators.


*Solaire Lights* is released under this
 [`LICENSE`](https://bitbucket.org/doktorstick/solaire-lights/src/tip/LICENSE?fileviewer=file-view-default).

# Releases

## 1.0.0 `Praise-the-Sun`

**Released:** 2016-10-01

This release marks the debut of *Solaire Lights*. 
